# 🎨 Pixel Texture Editor — Mod para Minecraft Java 26.1.1

Editor de pixel art integrado en el juego. Editá las texturas de bloques e
ítems sin salir de Minecraft, y exportalas como resource pack listo para usar.

---

## ✨ Características

| Función | Detalle |
|---|---|
| ✏️ Lápiz | Dibujá píxel por píxel |
| ⊗ Goma | Borrá (pone transparente) |
| ⬤ Relleno | Flood-fill con el color actual |
| ☀️ Cuentagotas | Seleccioná un color del canvas |
| ↩↪ Undo/Redo | 40 niveles (Ctrl+Z / Ctrl+Y) |
| 🖱️ Zoom | Rueda del mouse o botones [−][+] |
| 🎨 Paleta | 42 colores predefinidos |
| #️⃣ Hex input | Ingresá cualquier color ARGB |
| ✓ Aplicar | Cambia la textura al instante, sin reiniciar |
| ⬇️ Exportar | Guarda un `.zip` en `resourcepacks/` |

---

## 🚀 Instalación

### Requisitos
- **Minecraft Java Edition 26.1.1**
- **Java 25+**
- **Fabric Loader 0.18.4+**
- **Fabric API 0.120.0+26.1** (o superior para 26.1)

### Pasos
1. Instalá Fabric Loader para Minecraft 26.1.1 desde [fabricmc.net](https://fabricmc.net/use/installer/)
2. Descargá la última **Fabric API** para 26.1 desde [Modrinth](https://modrinth.com/mod/fabric-api)
3. Copiá `pixel-texture-editor-1.0.0.jar` y `fabric-api-*.jar` en la carpeta `mods/`
4. ¡Listo!

---

## 🎮 Cómo usar

### Opción A — Tecla rápida (recomendada)
1. Abrí el juego y parás frente a un bloque **O** tenés un ítem en la mano
2. Presioná **[P]** (configurable en Opciones → Controles)
3. Se abre el editor con la textura de ese bloque/ítem

### Opción B — Texture Wand (vara mágica)
1. Sacá la **Texture Wand** del inventario creativo (pestaña Herramientas)
2. Hacé **clic derecho** en cualquier bloque
3. Se abre el editor de ese bloque

---

## 🏗️ Compilar desde el código fuente

```bash
# Requiere Java 25 y Gradle 9.4
git clone https://github.com/yourname/pixel-texture-editor
cd pixel-texture-editor
./gradlew build
# El .jar queda en build/libs/pixel-texture-editor-1.0.0.jar
```

---

## 📦 Exportar como Resource Pack

1. Editá la textura en el editor
2. Hacé clic en **⬇️ Export Pack** (o Ctrl+S)
3. El archivo se guarda en:
   ```
   .minecraft/resourcepacks/PixelEdit_<nombre>_<timestamp>.zip
   ```
4. Activalo en **Opciones → Resource Packs** sin reiniciar el juego

---

## 📂 Estructura del mod

```
pixel-texture-editor/
├── src/main/java/com/pixeltextureeditor/
│   ├── PixelTextureEditorMod.java          ← Entrypoint principal
│   ├── item/
│   │   └── TextureWandItem.java            ← Ítem Texture Wand
│   └── client/
│       ├── PixelTextureEditorClient.java   ← Entrypoint cliente + keybind
│       ├── screen/
│       │   └── PixelArtEditorScreen.java   ← ★ El editor completo
│       └── util/
│           └── ResourcePackExporter.java   ← Apply in-game + Export ZIP
├── src/main/resources/
│   ├── fabric.mod.json
│   └── assets/pixel-texture-editor/
│       ├── lang/en_us.json
│       ├── items/texture_wand.json
│       └── models/item/texture_wand.json
├── build.gradle
├── gradle.properties
└── settings.gradle
```

---

## ⚠️ Notas técnicas

- Minecraft 26.1 es la **primera versión sin ofuscación** → no se necesitan
  Yarn mappings. El mod usa Mojang Mappings directamente.
- El `apply in-game` parchea el atlas de OpenGL en tiempo real. Funciona en
  mundos en curso; puede requerir re-entrar a un chunk para que los bloques
  ya renderizados se actualicen.
- El mod es **client-side only** — no necesitás instalarlo en el servidor.

---

## 📜 Licencia

MIT © 2026 — Usalo y modificalo libremente.
