@echo off
echo.
echo ====================================================
echo   Pixel Texture Editor - Compilador automatico
echo ====================================================
echo.

where gradle >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [!] Gradle no encontrado. Instalalo desde:
    echo     https://gradle.org/releases/
    echo     Descarga el "binary-only" zip, descomprimilo
    echo     y agrega la carpeta bin al PATH.
    echo.
    pause
    exit /b 1
)

echo [*] Compilando mod...
gradle build

if %ERRORLEVEL% equ 0 (
    echo.
    echo ====================================================
    echo   BUILD EXITOSO!
    echo   El archivo .jar esta en:
    echo   build\libs\pixel-texture-editor-1.0.0.jar
    echo ====================================================
    echo.
    echo Copia ese .jar a tu carpeta .minecraft\mods\
    echo.
) else (
    echo.
    echo [!] Hubo un error. Copia el mensaje de arriba y consultalo.
)
pause
