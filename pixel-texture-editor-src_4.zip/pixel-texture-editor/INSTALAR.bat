@echo off
setlocal enabledelayedexpansion
title Pixel Texture Editor - Instalador
color 0A

echo.
echo  ============================================================
echo    Pixel Texture Editor - Instalador automatico
echo  ============================================================
echo.

set "WORK=%~dp0"
set "MODS_DIR=%APPDATA%\.minecraft\mods"
set "JAR_OUT=%WORK%build\libs\pixel-texture-editor-1.0.0.jar"

:: ── PASO 1: Java ─────────────────────────────────────────────────────────────
echo  [1/3] Verificando Java 25...
java -version >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo        OK - Java encontrado.
) else (
    echo        Instalando Java 25 via winget...
    winget install --id EclipseAdoptium.Temurin.25.JDK -e --silent ^
        --accept-package-agreements --accept-source-agreements
    if !ERRORLEVEL! neq 0 (
        echo.
        echo  [!] Fallo la instalacion de Java.
        echo      Instala manualmente desde: https://adoptium.net
        echo      Elegí: Temurin 25 - Windows - x64 - JDK
        pause & exit /b 1
    )
    echo        Java 25 instalado OK.
    :: Recargar el PATH en esta sesion
    for /f "skip=2 tokens=3*" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v PATH 2^>nul') do set "PATH=%%a %%b"
)

:: ── PASO 2: Gradle ───────────────────────────────────────────────────────────
echo.
echo  [2/3] Verificando Gradle...
gradle -v >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo        OK - Gradle encontrado.
    goto :compilar
)

echo        Instalando Gradle via winget...
winget install --id Gradle.Gradle -e --silent ^
    --accept-package-agreements --accept-source-agreements
if %ERRORLEVEL% neq 0 (
    echo.
    echo  [!] winget no pudo instalar Gradle.
    echo      Probando instalacion manual...
    goto :gradle_manual
)

:: Recargar PATH para que gradle sea visible
for /f "skip=2 tokens=3*" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v PATH 2^>nul') do set "PATH=%%a %%b"
gradle -v >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo        Gradle instalado OK.
    goto :compilar
)

:gradle_manual
:: Descarga directa con barra de progreso via PowerShell
echo.
echo  Descargando Gradle 9.4.0 ^(130 MB^)...
echo  Por favor espera, esto puede tardar segun tu internet...
echo.
set "GRADLE_ZIP=%TEMP%\gradle-9.4.0-bin.zip"
set "GRADLE_HOME=%LOCALAPPDATA%\gradle-9.4.0"

powershell -NoProfile -Command ^
  "$ProgressPreference='Continue';" ^
  "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;" ^
  "Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-9.4.0-bin.zip'" ^
  "-OutFile '%GRADLE_ZIP%'"

if %ERRORLEVEL% neq 0 (
    echo.
    echo  [!] No se pudo descargar Gradle.
    echo      Verifica tu conexion a internet e intentalo de nuevo.
    pause & exit /b 1
)

echo  Extrayendo Gradle...
powershell -NoProfile -Command ^
  "Expand-Archive -Path '%GRADLE_ZIP%' -DestinationPath '%LOCALAPPDATA%' -Force"

set "PATH=%GRADLE_HOME%\bin;%PATH%"
echo        Gradle listo OK.

:: ── PASO 3: Compilar y copiar ────────────────────────────────────────────────
:compilar
echo.
echo  [3/3] Compilando el mod...
echo        ^(La primera vez descarga libs de Minecraft, ~2 min^)
echo.

cd /d "%WORK%"
call gradle build --no-daemon
if %ERRORLEVEL% neq 0 (
    echo.
    echo  [!] Error al compilar. Captura el mensaje rojo de arriba y consultalo.
    pause & exit /b 1
)

if not exist "%JAR_OUT%" (
    echo  [!] No se encontro el .jar generado.
    pause & exit /b 1
)

if not exist "%MODS_DIR%" mkdir "%MODS_DIR%"
copy /Y "%JAR_OUT%" "%MODS_DIR%\" >nul

echo.
echo  ============================================================
echo    INSTALACION COMPLETA!
echo.
echo    El mod esta en tu carpeta mods.
echo    Abri Minecraft con el perfil Fabric 26.1.1 y
echo    apreta [P] mirando cualquier bloque para editar
echo    su textura con el editor de pixel art.
echo  ============================================================
echo.
pause
