package com.pixeltextureeditor.client.screen;

import com.mojang.blaze3d.platform.NativeImage;
import com.pixeltextureeditor.client.util.ResourcePackExporter;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedList;
import java.util.Queue;

/**
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║                        PIXEL ART EDITOR SCREEN                          ║
 * ╠══════════════════════════════════════════════════════════════════════════╣
 * ║  Layout (approximate):                                                   ║
 * ║  ┌──────── TOOLBAR (tools + undo/redo) ──────────────────────────────┐   ║
 * ║  │  [✏ Pencil] [⊗ Eraser] [⬤ Fill] [☀ Pick]  [↩ Undo] [↪ Redo]   │   ║
 * ║  └──────────────────────────────────────────────────────────────────┘   ║
 * ║                                                                          ║
 * ║  ┌─ CANVAS ──────────────┐  ┌─ RIGHT PANEL ──────────────────────────┐  ║
 * ║  │  (zoomed pixel grid)  │  │  Current color preview                  │  ║
 * ║  │                       │  │  Palette swatches (7 × N rows)          │  ║
 * ║  │  click = draw         │  │  Hex input + R G B sliders              │  ║
 * ║  │  drag  = paint        │  │  Zoom [−] [+]                           │  ║
 * ║  └───────────────────────┘  └────────────────────────────────────────┘  ║
 * ║                                                                          ║
 * ║  ┌──── BOTTOM BAR ────────────────────────────────────────────────────┐  ║
 * ║  │  [✓ Apply In-Game]  [⬇ Export Pack]  [✕ Close]                   │  ║
 * ║  └──────────────────────────────────────────────────────────────────┘   ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 */
@Environment(EnvType.CLIENT)
public class PixelArtEditorScreen extends Screen {

    // ─── Input context ────────────────────────────────────────────────────
    @Nullable private final BlockState blockState;
    @Nullable private final ItemStack  itemStack;

    // ─── Texture ─────────────────────────────────────────────────────────
    @Nullable private NativeImage        image;
    @Nullable private ResourceLocation   textureLocation;
    private int imageWidth  = 16;
    private int imageHeight = 16;

    // ─── Canvas rendering ─────────────────────────────────────────────────
    private int pixelSize   = 12;   // screen pixels per texture pixel
    private int canvasX, canvasY;
    private boolean isPainting = false;

    // ─── Tools ───────────────────────────────────────────────────────────
    private enum Tool { PENCIL, ERASER, FILL, EYEDROPPER }
    private Tool currentTool = Tool.PENCIL;

    // ─── Colors (all stored internally as ARGB 0xAARRGGBB) ───────────────
    private int selectedColor = 0xFF_000000; // default: opaque black
    private static final int[] PALETTE = {
        // ── Row 1: Whites / Grays / Blacks ──────────────────────────────
        0xFF_FFFFFF, 0xFF_DDDDDD, 0xFF_AAAAAA, 0xFF_777777, 0xFF_444444, 0xFF_222222, 0xFF_000000,
        // ── Row 2: Reds / Oranges / Yellows ─────────────────────────────
        0xFF_FF2222, 0xFF_FF6600, 0xFF_FF9900, 0xFF_FFCC00, 0xFF_FFFF00, 0xFF_AAFF00, 0xFF_55FF00,
        // ── Row 3: Greens / Cyans ────────────────────────────────────────
        0xFF_00FF00, 0xFF_00FF66, 0xFF_00FFAA, 0xFF_00FFFF, 0xFF_00AAFF, 0xFF_0055FF, 0xFF_0022FF,
        // ── Row 4: Blues / Purples / Pinks ──────────────────────────────
        0xFF_0000FF, 0xFF_4400FF, 0xFF_8800FF, 0xFF_CC00FF, 0xFF_FF00FF, 0xFF_FF00AA, 0xFF_FF0055,
        // ── Row 5: Earth tones (Minecraft-ish) ──────────────────────────
        0xFF_5C3317, 0xFF_8B4513, 0xFF_CC7722, 0xFF_F5DEB3, 0xFF_228B22, 0xFF_006400, 0xFF_1B3A1B,
        // ── Row 6: Semi-transparent (useful for overlays) ────────────────
        0x00_000000, 0x40_FFFFFF, 0x80_FFFFFF, 0xC0_FFFFFF, 0x40_000000, 0x80_000000, 0xC0_000000,
    };
    private static final int PALETTE_COLS  = 7;
    private static final int SWATCH_SIZE   = 15; // px per swatch square

    // ─── Undo / Redo ─────────────────────────────────────────────────────
    private final Deque<int[]> undoStack = new ArrayDeque<>();
    private final Deque<int[]> redoStack = new ArrayDeque<>();
    private static final int MAX_UNDO = 40;

    // ─── Widgets ─────────────────────────────────────────────────────────
    @Nullable private EditBox hexInputBox;

    // ─── Constructor ─────────────────────────────────────────────────────

    public PixelArtEditorScreen(@Nullable BlockState blockState,
                                 @Nullable ItemStack itemStack) {
        super(Component.literal("Pixel Texture Editor"));
        this.blockState = blockState;
        this.itemStack  = itemStack;
    }

    // ═════════════════════════════════════════════════════════════════════
    //  INIT
    // ═════════════════════════════════════════════════════════════════════

    @Override
    protected void init() {
        loadTexture();
        calculateLayout();
        buildWidgets();
    }

    private void calculateLayout() {
        // Allocate ~60% of screen width and full height (minus toolbar + bottom)
        int maxCanvasW = (int)(this.width  * 0.58);
        int maxCanvasH = this.height - 80;
        int pxW = maxCanvasW / Math.max(imageWidth,  1);
        int pxH = maxCanvasH / Math.max(imageHeight, 1);
        pixelSize = Math.max(2, Math.min(24, Math.min(pxW, pxH)));

        canvasX = 10;
        canvasY = 36;
    }

    private void buildWidgets() {
        // ── Toolbar ────────────────────────────────────────────────────────
        final int TY = 10, BW = 60, BH = 18;
        addRenderableWidget(mkBtn("✏ Pencil",    10,       TY, BW, BH, b -> currentTool = Tool.PENCIL));
        addRenderableWidget(mkBtn("⊗ Eraser",    73,       TY, BW, BH, b -> currentTool = Tool.ERASER));
        addRenderableWidget(mkBtn("⬤ Fill",     136,       TY, BW, BH, b -> currentTool = Tool.FILL));
        addRenderableWidget(mkBtn("☀ Pick",     197,       TY, BW, BH, b -> currentTool = Tool.EYEDROPPER));
        addRenderableWidget(mkBtn("↩ Undo",     268,       TY, BW, BH, b -> undo()));
        addRenderableWidget(mkBtn("↪ Redo",     331,       TY, BW, BH, b -> redo()));

        // ── Zoom buttons ──────────────────────────────────────────────────
        int rightX = getRightPanelX();
        addRenderableWidget(mkBtn("[-]", rightX, TY, 25, BH, b -> { pixelSize = Math.max(2,  pixelSize - 2); }));
        addRenderableWidget(mkBtn("[+]", rightX + 28, TY, 25, BH, b -> { pixelSize = Math.min(32, pixelSize + 2); }));

        // ── Hex color input ───────────────────────────────────────────────
        int hexY = getRightPanelY() + getPaletteRows() * SWATCH_SIZE + 30;
        hexInputBox = new EditBox(font,
                rightX, hexY, 86, 14,
                Component.literal("Hex color"));
        hexInputBox.setMaxLength(9);
        hexInputBox.setValue(argbToHex(selectedColor));
        hexInputBox.setResponder(this::onHexChanged);
        addRenderableWidget(hexInputBox);

        // ── Bottom bar ────────────────────────────────────────────────────
        int bottomY = this.height - 22;
        addRenderableWidget(mkBtn("✓ Apply In-Game",   10,  bottomY, 125, 18, b -> applyInGame()));
        addRenderableWidget(mkBtn("⬇ Export Pack",    140,  bottomY, 115, 18, b -> exportPack()));
        addRenderableWidget(mkBtn("✕ Close",           260, bottomY,  55, 18, b -> onClose()));
    }

    // Convenience helper to avoid boilerplate
    private static Button mkBtn(String label, int x, int y, int w, int h,
                                 Button.OnPress onPress) {
        return Button.builder(Component.literal(label), onPress)
                .bounds(x, y, w, h)
                .build();
    }

    // ═════════════════════════════════════════════════════════════════════
    //  TEXTURE LOADING
    // ═════════════════════════════════════════════════════════════════════

    private void loadTexture() {
        textureLocation = resolveTextureLocation();
        if (textureLocation != null) {
            try (InputStream stream = minecraft.getResourceManager().open(textureLocation)) {
                image       = NativeImage.read(stream);
                imageWidth  = image.getWidth();
                imageHeight = image.getHeight();
                return;
            } catch (IOException e) {
                // Fall through → blank
            }
        }
        // Blank 16×16 fallback
        image       = new NativeImage(NativeImage.Format.RGBA, 16, 16, true);
        imageWidth  = 16;
        imageHeight = 16;
    }

    /**
     * Derives the resource-manager path (e.g. "minecraft:textures/block/stone.png")
     * from the block model's particle sprite or from the item model.
     */
    @Nullable
    private ResourceLocation resolveTextureLocation() {
        try {
            if (blockState != null) {
                var sprite = minecraft.getBlockRenderer()
                        .getBlockModelShaper()
                        .getBlockModel(blockState)
                        .getParticleIcon();
                // sprite.contents().name() → e.g. "minecraft:block/stone"
                var name = sprite.contents().name();
                return ResourceLocation.fromNamespaceAndPath(
                        name.getNamespace(),
                        "textures/" + name.getPath() + ".png");
            }
            if (itemStack != null) {
                var model  = minecraft.getItemRenderer().getModel(itemStack, null, null, 0);
                var sprite = model.getParticleIcon();
                var name   = sprite.contents().name();
                return ResourceLocation.fromNamespaceAndPath(
                        name.getNamespace(),
                        "textures/" + name.getPath() + ".png");
            }
        } catch (Exception ignored) {}
        return null;
    }

    // ═════════════════════════════════════════════════════════════════════
    //  RENDERING
    // ═════════════════════════════════════════════════════════════════════

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        renderHeader(g);
        renderCanvas(g, mouseX, mouseY);
        renderRightPanel(g, mouseX, mouseY);
        renderStatusBar(g, mouseX, mouseY);
        super.render(g, mouseX, mouseY, delta);   // renders widgets on top
    }

    private void renderHeader(GuiGraphics g) {
        String label = "§6Pixel Texture Editor";
        if (textureLocation != null)
            label += " §7› §f" + textureLocation.getNamespace() + ":§e" + textureLocation.getPath();
        g.drawString(font, label, canvasX, canvasY - 12, 0xFFFFFFFF);
    }

    private void renderCanvas(GuiGraphics g, int mouseX, int mouseY) {
        if (image == null) return;

        int cx = canvasX, cy = canvasY;
        int cw = imageWidth * pixelSize, ch = imageHeight * pixelSize;

        // ── Checkerboard background (shows transparency) ──────────────────
        for (int py = 0; py < imageHeight; py++) {
            for (int px = 0; px < imageWidth; px++) {
                int color = ((px + py) % 2 == 0) ? 0xFF808080 : 0xFF606060;
                int x0 = cx + px * pixelSize, y0 = cy + py * pixelSize;
                g.fill(x0, y0, x0 + pixelSize, y0 + pixelSize, color);
            }
        }

        // ── Draw pixels ───────────────────────────────────────────────────
        for (int py = 0; py < imageHeight; py++) {
            for (int px = 0; px < imageWidth; px++) {
                int raw  = image.getPixelRGBA(px, py);
                int argb = rawToArgb(raw);
                if ((argb >>> 24) == 0) continue;  // skip fully transparent
                int x0 = cx + px * pixelSize, y0 = cy + py * pixelSize;
                g.fill(x0, y0, x0 + pixelSize, y0 + pixelSize, argb);
            }
        }

        // ── Grid lines (only when pixels are big enough to see them) ─────
        if (pixelSize >= 4) {
            int gridCol = 0x22_000000;
            for (int py = 0; py <= imageHeight; py++)
                g.fill(cx, cy + py * pixelSize, cx + cw, cy + py * pixelSize + 1, gridCol);
            for (int px = 0; px <= imageWidth; px++)
                g.fill(cx + px * pixelSize, cy, cx + px * pixelSize + 1, cy + ch, gridCol);
        }

        // ── Canvas border ─────────────────────────────────────────────────
        g.fill(cx - 1, cy - 1, cx + cw + 1, cy,          0xFF_AAAAAA);
        g.fill(cx - 1, cy + ch, cx + cw + 1, cy + ch + 1,0xFF_AAAAAA);
        g.fill(cx - 1, cy - 1, cx,           cy + ch + 1, 0xFF_AAAAAA);
        g.fill(cx + cw, cy - 1, cx + cw + 1, cy + ch + 1,0xFF_AAAAAA);

        // ── Hover highlight ───────────────────────────────────────────────
        int[] hov = getPixelAt(mouseX, mouseY);
        if (hov != null) {
            int hx = cx + hov[0] * pixelSize, hy = cy + hov[1] * pixelSize;
            int hl = 0xFF_FFFFFF;
            g.fill(hx,                hy,                hx + pixelSize,     hy + 1,              hl);
            g.fill(hx,                hy + pixelSize - 1,hx + pixelSize,     hy + pixelSize,      hl);
            g.fill(hx,                hy,                hx + 1,             hy + pixelSize,      hl);
            g.fill(hx + pixelSize - 1,hy,                hx + pixelSize,     hy + pixelSize,      hl);
        }
    }

    private void renderRightPanel(GuiGraphics g, int mouseX, int mouseY) {
        int rx  = getRightPanelX();
        int ry  = getRightPanelY();
        int pw  = PALETTE_COLS * SWATCH_SIZE;

        // ── Selected color preview ────────────────────────────────────────
        // Checkerboard behind preview (for alpha)
        g.fill(rx, ry, rx + pw, ry + 22, 0xFF_333333);
        for (int tx = 0; tx < 5; tx++)
            for (int ty = 0; ty < 2; ty++) {
                int c = ((tx + ty) % 2 == 0) ? 0xFF_666666 : 0xFF_888888;
                g.fill(rx + tx * 20, ry + 2 + ty * 9, rx + tx * 20 + 20, ry + 2 + ty * 9 + 9, c);
            }
        g.fill(rx, ry, rx + pw, ry + 22, selectedColor);   // actual color on top
        g.fill(rx, ry, rx + pw, ry + 1,  0xFF_AAAAAA);
        g.fill(rx, ry + 21, rx + pw, ry + 22, 0xFF_AAAAAA);

        String toolLabel = "§7Tool: §e" + currentTool.name().charAt(0)
                + currentTool.name().substring(1).toLowerCase()
                + " §7| §fZoom: §e" + pixelSize + "px";
        g.drawString(font, toolLabel, rx, ry + 26, 0xFFFFFF);

        ry += 40;

        // ── Palette label ─────────────────────────────────────────────────
        g.drawString(font, "§7Palette:", rx, ry - 10, 0xFFFFFF);

        // ── Palette swatches ──────────────────────────────────────────────
        for (int i = 0; i < PALETTE.length; i++) {
            int col = i % PALETTE_COLS;
            int row = i / PALETTE_COLS;
            int sx  = rx + col * SWATCH_SIZE;
            int sy  = ry + row * SWATCH_SIZE;
            int sx2 = sx + SWATCH_SIZE - 1;
            int sy2 = sy + SWATCH_SIZE - 1;
            int color = PALETTE[i];

            // Checkerboard for semi-transparent swatches
            if ((color >>> 24) < 0xFF) {
                for (int ty = 0; ty < 2; ty++)
                    for (int tx = 0; tx < 2; tx++) {
                        int bc = ((tx + ty) % 2 == 0) ? 0xFF_888888 : 0xFF_666666;
                        g.fill(sx + tx * 7, sy + ty * 7, sx + tx * 7 + 7, sy + ty * 7 + 7, bc);
                    }
            }
            g.fill(sx, sy, sx2, sy2, color);

            // Yellow border for selected color
            if (color == selectedColor) {
                g.fill(sx - 1, sy - 1, sx2 + 1, sy,     0xFF_FFFF00);
                g.fill(sx - 1, sy2,    sx2 + 1, sy2 + 1, 0xFF_FFFF00);
                g.fill(sx - 1, sy - 1, sx,      sy2 + 1, 0xFF_FFFF00);
                g.fill(sx2,    sy - 1, sx2 + 1, sy2 + 1, 0xFF_FFFF00);
            }

            // Tooltip on hover
            if (mouseX >= sx && mouseX < sx2 && mouseY >= sy && mouseY < sy2) {
                g.renderTooltip(font,
                        Component.literal(argbToHex(color)),
                        mouseX, mouseY);
            }
        }

        // ── Hex label (the EditBox widget is rendered by super.render) ────
        int hexLabelY = ry + getPaletteRows() * SWATCH_SIZE + 16;
        g.drawString(font, "§7Hex:", rx, hexLabelY, 0xFFFFFF);
    }

    private void renderStatusBar(GuiGraphics g, int mouseX, int mouseY) {
        int[] hov = getPixelAt(mouseX, mouseY);
        if (hov == null || image == null) return;
        int raw  = image.getPixelRGBA(hov[0], hov[1]);
        int argb = rawToArgb(raw);
        String info = String.format("§7Pixel [%d, %d]  §f%s  §7A=%d R=%d G=%d B=%d",
                hov[0], hov[1], argbToHex(argb),
                (argb >> 24) & 0xFF, (argb >> 16) & 0xFF,
                (argb >>  8) & 0xFF,  argb        & 0xFF);
        g.drawString(font, info, canvasX, this.height - 34, 0x888888);
    }

    // ═════════════════════════════════════════════════════════════════════
    //  INPUT HANDLING
    // ═════════════════════════════════════════════════════════════════════

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // ── Palette click ─────────────────────────────────────────────────
        int rx = getRightPanelX(), ry = getRightPanelY() + 40;
        for (int i = 0; i < PALETTE.length; i++) {
            int col = i % PALETTE_COLS, row = i / PALETTE_COLS;
            int sx = rx + col * SWATCH_SIZE, sy = ry + row * SWATCH_SIZE;
            if (mx >= sx && mx < sx + SWATCH_SIZE - 1
             && my >= sy && my < sy + SWATCH_SIZE - 1) {
                selectedColor = PALETTE[i];
                syncHexBox();
                return true;
            }
        }

        // ── Canvas click ──────────────────────────────────────────────────
        int[] px = getPixelAt((int) mx, (int) my);
        if (px != null) {
            isPainting = true;
            pushUndo();
            applyTool(px[0], px[1]);
            return true;
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (isPainting && (currentTool == Tool.PENCIL || currentTool == Tool.ERASER)) {
            int[] px = getPixelAt((int) mx, (int) my);
            if (px != null) {
                applyTool(px[0], px[1]);
                return true;
            }
        }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        isPainting = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hScroll, double vScroll) {
        // Scroll inside canvas → zoom in/out
        if (isInsideCanvas((int) mx, (int) my)) {
            pixelSize = (int) Math.max(2, Math.min(32, pixelSize + vScroll));
            return true;
        }
        return super.mouseScrolled(mx, my, hScroll, vScroll);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        boolean ctrl = (mods & GLFW.GLFW_MOD_CONTROL) != 0;
        if (ctrl) {
            if (key == GLFW.GLFW_KEY_Z) { undo();       return true; }
            if (key == GLFW.GLFW_KEY_Y) { redo();       return true; }
            if (key == GLFW.GLFW_KEY_S) { exportPack(); return true; }
        }
        return super.keyPressed(key, scan, mods);
    }

    // ═════════════════════════════════════════════════════════════════════
    //  TOOL LOGIC
    // ═════════════════════════════════════════════════════════════════════

    private void applyTool(int px, int py) {
        if (image == null) return;
        switch (currentTool) {
            case PENCIL     -> image.setPixelRGBA(px, py, argbToRaw(selectedColor));
            case ERASER     -> image.setPixelRGBA(px, py, 0);          // fully transparent
            case FILL       -> floodFill(px, py);
            case EYEDROPPER -> {
                selectedColor = rawToArgb(image.getPixelRGBA(px, py));
                syncHexBox();
                currentTool = Tool.PENCIL;   // auto-switch back to pencil
            }
        }
    }

    /** BFS flood-fill from (startX, startY) with the current selectedColor. */
    private void floodFill(int startX, int startY) {
        if (image == null) return;
        int target = image.getPixelRGBA(startX, startY);
        int fill   = argbToRaw(selectedColor);
        if (target == fill) return;

        Queue<int[]> queue   = new LinkedList<>();
        boolean[][] visited  = new boolean[imageHeight][imageWidth];
        queue.add(new int[]{startX, startY});

        while (!queue.isEmpty()) {
            int[] pos = queue.poll();
            int x = pos[0], y = pos[1];
            if (x < 0 || x >= imageWidth || y < 0 || y >= imageHeight) continue;
            if (visited[y][x]) continue;
            if (image.getPixelRGBA(x, y) != target) continue;

            visited[y][x] = true;
            image.setPixelRGBA(x, y, fill);
            queue.add(new int[]{x + 1, y});
            queue.add(new int[]{x - 1, y});
            queue.add(new int[]{x, y + 1});
            queue.add(new int[]{x, y - 1});
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    //  UNDO / REDO
    // ═════════════════════════════════════════════════════════════════════

    private void pushUndo() {
        if (image == null) return;
        undoStack.push(snapshot());
        if (undoStack.size() > MAX_UNDO) undoStack.pollLast();
        redoStack.clear();
    }

    private void undo() {
        if (undoStack.isEmpty()) return;
        redoStack.push(snapshot());
        restore(undoStack.pop());
    }

    private void redo() {
        if (redoStack.isEmpty()) return;
        undoStack.push(snapshot());
        restore(redoStack.pop());
    }

    private int[] snapshot() {
        int[] snap = new int[imageWidth * imageHeight];
        for (int y = 0; y < imageHeight; y++)
            for (int x = 0; x < imageWidth; x++)
                snap[y * imageWidth + x] = image.getPixelRGBA(x, y);
        return snap;
    }

    private void restore(int[] snap) {
        for (int y = 0; y < imageHeight; y++)
            for (int x = 0; x < imageWidth; x++)
                image.setPixelRGBA(x, y, snap[y * imageWidth + x]);
    }

    // ═════════════════════════════════════════════════════════════════════
    //  APPLY / EXPORT
    // ═════════════════════════════════════════════════════════════════════

    /** Modifies the OpenGL texture atlas in-place (no game restart required). */
    private void applyInGame() {
        if (image == null || textureLocation == null) return;
        ResourcePackExporter.applyToAtlas(blockState, itemStack, image, minecraft);
    }

    /** Saves a ready-to-install .zip resource pack to the resourcepacks folder. */
    private void exportPack() {
        if (image == null || textureLocation == null) return;
        String saved = ResourcePackExporter.exportAsZip(textureLocation, image, minecraft);
        if (saved != null) {
            minecraft.execute(() -> minecraft.player.displayClientMessage(
                    Component.literal("§a[Pixel Editor] Pack saved → §e" + saved), false));
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    //  HEX BOX
    // ═════════════════════════════════════════════════════════════════════

    private void onHexChanged(String value) {
        try {
            String hex = value.startsWith("#") ? value.substring(1) : value;
            if (hex.length() == 6) hex = "FF" + hex;   // assume opaque
            if (hex.length() == 8)
                selectedColor = (int) Long.parseLong(hex, 16);
        } catch (NumberFormatException ignored) {}
    }

    private void syncHexBox() {
        if (hexInputBox != null) hexInputBox.setValue(argbToHex(selectedColor));
    }

    // ═════════════════════════════════════════════════════════════════════
    //  HELPERS – LAYOUT
    // ═════════════════════════════════════════════════════════════════════

    /** X coordinate of the right info/palette panel. */
    private int getRightPanelX() { return canvasX + imageWidth * pixelSize + 14; }

    /** Y coordinate where the right panel starts (aligned with canvas). */
    private int getRightPanelY() { return canvasY; }

    private int getPaletteRows() {
        return (PALETTE.length + PALETTE_COLS - 1) / PALETTE_COLS;
    }

    @Nullable
    private int[] getPixelAt(int mx, int my) {
        if (image == null) return null;
        int relX = mx - canvasX, relY = my - canvasY;
        if (relX < 0 || relY < 0) return null;
        int px = relX / pixelSize, py = relY / pixelSize;
        if (px >= imageWidth || py >= imageHeight) return null;
        return new int[]{px, py};
    }

    private boolean isInsideCanvas(int mx, int my) {
        return mx >= canvasX && mx < canvasX + imageWidth  * pixelSize
            && my >= canvasY && my < canvasY + imageHeight * pixelSize;
    }

    // ═════════════════════════════════════════════════════════════════════
    //  HELPERS – COLOR CONVERSION
    // ═════════════════════════════════════════════════════════════════════
    //
    //  NativeImage.getPixelRGBA / setPixelRGBA uses "raw" format:
    //    bits 31-24 = A,  23-16 = B,  15-8 = G,  7-0 = R   (ABGR int)
    //
    //  GuiGraphics.fill / our selectedColor uses ARGB:
    //    bits 31-24 = A,  23-16 = R,  15-8 = G,  7-0 = B
    //
    // ─────────────────────────────────────────────────────────────────────

    /** NativeImage raw (ABGR int) → GuiGraphics / selectedColor (ARGB int) */
    private static int rawToArgb(int raw) {
        int a = (raw >> 24) & 0xFF, b = (raw >> 16) & 0xFF,
            g = (raw >>  8) & 0xFF, r =  raw        & 0xFF;
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** GuiGraphics / selectedColor (ARGB int) → NativeImage raw (ABGR int) */
    private static int argbToRaw(int argb) {
        int a = (argb >> 24) & 0xFF, r = (argb >> 16) & 0xFF,
            g = (argb >>  8) & 0xFF, b =  argb        & 0xFF;
        return (a << 24) | (b << 16) | (g << 8) | r;
    }

    /** Formats an ARGB int as "#AARRGGBB". */
    private static String argbToHex(int argb) {
        return String.format("#%08X", argb & 0xFFFFFFFFL);
    }

    // ═════════════════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ═════════════════════════════════════════════════════════════════════

    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void onClose() {
        if (image != null) { image.close(); image = null; }
        super.onClose();
    }
}
