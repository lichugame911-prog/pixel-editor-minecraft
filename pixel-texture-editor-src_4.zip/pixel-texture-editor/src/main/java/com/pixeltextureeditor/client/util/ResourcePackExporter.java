package com.pixeltextureeditor.client.util;

import com.mojang.blaze3d.platform.NativeImage;
import com.pixeltextureeditor.PixelTextureEditorMod;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.zip.*;

/**
 * Two-function utility:
 *
 *  ① applyToAtlas()  – patches the live OpenGL texture atlas so you see the
 *                      change instantly without restarting Minecraft.
 *
 *  ② exportAsZip()   – writes a complete, ready-to-install resource-pack .zip
 *                      into the game's resourcepacks folder.
 */
@Environment(EnvType.CLIENT)
public final class ResourcePackExporter {

    private ResourcePackExporter() {}

    // ═══════════════════════════════════════════════════════════════════════
    //  ① APPLY IN-GAME
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Replaces the sprite's pixels on the GPU atlas so the change is visible
     * instantly in the running game.
     *
     * Strategy:
     *  • Find the TextureAtlas that owns the sprite for this block/item.
     *  • Write the edited NativeImage pixels directly into the atlas NativeImage
     *    at the sprite's UV offset.
     *  • Upload the dirty region to GPU via AbstractTexture.bind() +
     *    NativeImage.upload().
     *
     * Note: Minecraft 26.1 exposes enough public API for this without
     * reflection/mixins – the atlas image is accessible via
     * TextureAtlasSprite.contents().byMipLevel()[0].
     */
    public static void applyToAtlas(@Nullable BlockState blockState,
                                    @Nullable ItemStack  itemStack,
                                    NativeImage          edited,
                                    Minecraft            mc) {
        try {
            TextureAtlasSprite sprite = getSprite(blockState, itemStack, mc);
            if (sprite == null) {
                warn("Could not find sprite for the target block/item.");
                return;
            }

            // The sprite content's mip-level 0 is the raw NativeImage on the atlas.
            NativeImage atlasImg = sprite.contents().byMipLevel()[0];

            int u0 = sprite.getX();   // atlas pixel offset X
            int v0 = sprite.getY();   // atlas pixel offset Y
            int sw = sprite.contents().width();
            int sh = sprite.contents().height();

            // Copy edited pixels → atlas image
            for (int y = 0; y < sh && y < edited.getHeight(); y++) {
                for (int x = 0; x < sw && x < edited.getWidth(); x++) {
                    atlasImg.setPixelRGBA(u0 + x, v0 + y, edited.getPixelRGBA(x, y));
                }
            }

            // Find and re-upload the atlas texture
            ResourceLocation atlasLoc = getAtlasLocation(blockState, itemStack);
            AbstractTexture atlasTex  = mc.getTextureManager().getTexture(atlasLoc);
            if (atlasTex instanceof TextureAtlas ta) {
                ta.bind();
                // Upload the dirty region to GPU
                atlasImg.upload(0, u0, v0, u0, v0, sw, sh, false, false);
            }

            info("Applied texture changes to atlas in real time.");

        } catch (Exception e) {
            warn("applyToAtlas failed: " + e.getMessage());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  ② EXPORT AS RESOURCE-PACK ZIP
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Creates a minimal but fully valid resource-pack .zip containing:
     *   pack.mcmeta
     *   assets/<namespace>/textures/<path>.png
     *
     * The pack is written to {@code <gameDir>/resourcepacks/} and its filename
     * is returned (or null on error).
     */
    @Nullable
    public static String exportAsZip(ResourceLocation textureLoc,
                                     NativeImage       edited,
                                     Minecraft         mc) {
        String timestamp = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String zipName   = "PixelEdit_" + textureLoc.getPath()
                .replace("textures/", "")
                .replace("/", "_")
                .replace(".png", "")
                + "_" + timestamp + ".zip";

        Path resourcePacksDir = mc.gameDirectory.toPath().resolve("resourcepacks");
        Path zipPath          = resourcePacksDir.resolve(zipName);

        try {
            Files.createDirectories(resourcePacksDir);

            try (ZipOutputStream zos = new ZipOutputStream(
                    new BufferedOutputStream(Files.newOutputStream(zipPath)))) {

                // ── pack.mcmeta ──────────────────────────────────────────
                // pack_format 101 matches Minecraft 26.1 (pack format 101.1)
                writeZipEntry(zos, "pack.mcmeta",
                        ("{\n" +
                         "  \"pack\": {\n" +
                         "    \"pack_format\": 101,\n" +
                         "    \"description\": \"Exported by Pixel Texture Editor – "
                         + textureLoc + "\"\n" +
                         "  }\n" +
                         "}\n").getBytes());

                // ── Texture PNG ──────────────────────────────────────────
                // textureLoc is already "namespace:textures/block/foo.png"
                String entryPath = "assets/" + textureLoc.getNamespace()
                                 + "/" + textureLoc.getPath();
                byte[] pngBytes = toPngBytes(edited);
                if (pngBytes == null) throw new IOException("PNG encoding failed");
                writeZipEntry(zos, entryPath, pngBytes);
            }

            info("Resource pack exported → " + zipPath);
            return zipName;

        } catch (Exception e) {
            warn("exportAsZip failed: " + e.getMessage());
            return null;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  HELPERS
    // ═══════════════════════════════════════════════════════════════════════

    @Nullable
    private static TextureAtlasSprite getSprite(@Nullable BlockState blockState,
                                                @Nullable ItemStack  itemStack,
                                                Minecraft mc) {
        try {
            if (blockState != null) {
                return mc.getBlockRenderer()
                         .getBlockModelShaper()
                         .getBlockModel(blockState)
                         .getParticleIcon();
            }
            if (itemStack != null) {
                return mc.getItemRenderer()
                         .getModel(itemStack, null, null, 0)
                         .getParticleIcon();
            }
        } catch (Exception ignored) {}
        return null;
    }

    private static ResourceLocation getAtlasLocation(@Nullable BlockState blockState,
                                                      @Nullable ItemStack  itemStack) {
        // Blocks live on the "block" atlas; items on the "item" atlas.
        // Both are sub-atlases of the main block atlas in modern MC.
        if (blockState != null)
            return TextureAtlas.LOCATION_BLOCKS;
        return TextureAtlas.LOCATION_BLOCKS; // items also use the block atlas
    }

    private static void writeZipEntry(ZipOutputStream zos, String name, byte[] data)
            throws IOException {
        ZipEntry entry = new ZipEntry(name);
        zos.putNextEntry(entry);
        zos.write(data);
        zos.closeEntry();
    }

    /**
     * Encodes a NativeImage (ABGR) as standard RGBA PNG bytes.
     * Uses AWT BufferedImage as an intermediate so we don't need extra libs.
     */
    @Nullable
    private static byte[] toPngBytes(NativeImage img) {
        try {
            int w = img.getWidth(), h = img.getHeight();
            BufferedImage buf = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int raw  = img.getPixelRGBA(x, y);
                    // raw = ABGR → AWT wants ARGB
                    int a = (raw >> 24) & 0xFF, b = (raw >> 16) & 0xFF,
                        g = (raw >>  8) & 0xFF, r =  raw        & 0xFF;
                    buf.setRGB(x, y, (a << 24) | (r << 16) | (g << 8) | b);
                }
            }
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(buf, "PNG", baos);
            return baos.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    private static void info(String msg)  { PixelTextureEditorMod.LOGGER.info("[PixelEdit] {}",  msg); }
    private static void warn(String msg)  { PixelTextureEditorMod.LOGGER.warn("[PixelEdit] {}",  msg); }
}
