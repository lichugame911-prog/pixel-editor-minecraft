package com.pixeltextureeditor.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.pixeltextureeditor.client.screen.PixelArtEditorScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import org.lwjgl.glfw.GLFW;

/**
 * Client entrypoint – registers the keybind and the tick event that opens
 * the Pixel Art Editor.
 *
 * HOW TO USE:
 *   ① Hold the Texture Wand and right-click a block → opens the block editor.
 *   ② Press [P] (default) while:
 *        • Your crosshair is on a block  → edits that block's texture.
 *        • You are holding any other item → edits that item's texture.
 */
@Environment(EnvType.CLIENT)
public class PixelTextureEditorClient implements ClientModInitializer {

    /** The keybind that opens the editor (default: P). */
    public static KeyMapping OPEN_EDITOR_KEY;

    @Override
    public void onInitializeClient() {
        OPEN_EDITOR_KEY = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.pixel-texture-editor.open_editor",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_P,
                "key.categories.pixel-texture-editor"
        ));

        // Each game tick, check if the player pressed the keybind
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.level == null) return;

            while (OPEN_EDITOR_KEY.consumeClick()) {
                openEditorForTarget(client);
            }
        });
    }

    /**
     * Determines *what* the player is looking at / holding and opens the
     * appropriate texture editor.
     */
    private static void openEditorForTarget(Minecraft client) {
        HitResult hit = client.hitResult;

        if (hit instanceof BlockHitResult blockHit
                && hit.getType() == HitResult.Type.BLOCK) {
            // ── Looking at a block ────────────────────────────────────────────
            var blockState = client.level.getBlockState(blockHit.getBlockPos());
            client.setScreen(new PixelArtEditorScreen(blockState, null));

        } else {
            // ── Not looking at a block → use held item ────────────────────────
            ItemStack main = client.player.getMainHandItem();
            ItemStack off  = client.player.getOffhandItem();

            ItemStack target = !main.isEmpty() ? main :
                               !off.isEmpty()  ? off  : ItemStack.EMPTY;

            if (!target.isEmpty()) {
                client.setScreen(new PixelArtEditorScreen(null, target));
            }
        }
    }
}
