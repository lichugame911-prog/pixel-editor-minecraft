package com.pixeltextureeditor;

import com.pixeltextureeditor.item.TextureWandItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PixelTextureEditorMod implements ModInitializer {

    public static final String MOD_ID = "pixel-texture-editor";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Texture Wand: right-click a block to open the pixel editor for that block. */
    public static final Item TEXTURE_WAND = new TextureWandItem(
            new Item.Properties().stacksTo(1));

    @Override
    public void onInitialize() {
        // Register the Texture Wand item
        Registry.register(
                BuiltInRegistries.ITEM,
                ResourceLocation.fromNamespaceAndPath(MOD_ID, "texture_wand"),
                TEXTURE_WAND);

        // Add to the "Tools & Utilities" creative tab
        CreativeModeTabEvents
                .modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(content -> content.accept(TEXTURE_WAND));

        LOGGER.info("[Pixel Texture Editor] Initialized! Press P in-game to open the editor.");
    }
}
