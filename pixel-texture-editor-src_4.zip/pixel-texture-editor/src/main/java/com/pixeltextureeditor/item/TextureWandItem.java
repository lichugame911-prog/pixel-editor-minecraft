package com.pixeltextureeditor.item;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Right-click a block while holding this item → opens the Pixel Art Editor
 * for that block's texture.
 *
 * All actual screen-opening logic is guarded by isClientSide() so the server
 * never tries to load client-only classes.
 */
public class TextureWandItem extends Item {

    public TextureWandItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        if (ctx.getLevel().isClientSide()) {
            BlockState blockState = ctx.getLevel().getBlockState(ctx.getClickedPos());
            openEditorClient(blockState);
        }
        // sidedSuccess: returns SUCCESS on client (preventing server round-trip),
        // CONSUME on server (suppresses default use behavior).
        return InteractionResult.sidedSuccess(ctx.getLevel().isClientSide());
    }

    /**
     * This method only executes on the client side (guarded by the isClientSide()
     * check in useOn). Splitting it keeps the server classpath free of Screen/Minecraft.
     */
    @Environment(EnvType.CLIENT)
    private static void openEditorClient(BlockState blockState) {
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
        mc.execute(() -> mc.setScreen(
                new com.pixeltextureeditor.client.screen.PixelArtEditorScreen(blockState, null)));
    }
}
